KEILA IA PARA DISCORD — PROYECTO FUENTE

REQUISITOS
- Node.js 20 o superior en un ordenador o servidor.
- Una aplicación/bot creado en Discord Developer Portal.
- Una clave de API de un proveedor compatible con la API de chat completions.

INSTALACIÓN
1. Descomprime el ZIP.
2. Copia .env.example y renombra la copia a .env.
3. Completa DISCORD_TOKEN, DISCORD_CLIENT_ID, DISCORD_GUILD_ID y OWNER_USER_ID.
4. Completa AI_API_KEY, AI_BASE_URL y AI_MODEL según tu proveedor.
5. En Discord Developer Portal > Bot activa Message Content Intent.
6. Invita el bot con scopes bot y applications.commands; permisos View Channels, Send Messages y Use Application Commands.
7. En la terminal de esta carpeta ejecuta: npm install
8. Ejecuta: npm run deploy
9. Ejecuta: npm start

COMANDOS
/keila mensaje — conversar con KEILA.
/programacion — enviar al propietario el ZIP fuente.
/nueva-version archivo — recibir un ZIP modificado para revisión.
/ayuda — mostrar comandos.

EDICIÓN
El bot incluye un ZIP interno llamado keila-source.zip. El propietario puede pedirlo con
/programacion, editarlo y devolverlo con /nueva-version. La nueva versión se guarda en
updates/pending y NO se instala ni ejecuta automáticamente. Debe revisarse, probarse y
aprobarse antes de aplicarla.

CORRECTOR
Si hay faltas ortográficas en mensajes normales, KEILA señala las palabras y su corrección.
Si el texto está bien escrito, responde directamente sin anunciar una revisión.
El corrector omite permisos, prohibiciones, restricciones, roles, autorizaciones y reglas
de seguridad. No altera esos apartados.

SEGURIDAD
- Nunca compartas DISCORD_TOKEN ni AI_API_KEY.
- No incluyas .env en los ZIP que envíes.
- Si se filtra el token, revócalo y genera uno nuevo en Developer Portal.
- El bot no compra ni vende criptomonedas.
- No automatiza cuentas personales; usa una cuenta de bot oficial de Discord.
