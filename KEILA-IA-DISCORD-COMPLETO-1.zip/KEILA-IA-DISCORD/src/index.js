require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { Client, GatewayIntentBits, Events } = require('discord.js');

if (!process.env.DISCORD_TOKEN || !process.env.OWNER_USER_ID) throw new Error('Completa DISCORD_TOKEN y OWNER_USER_ID en .env');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });
const isOwner = id => id === process.env.OWNER_USER_ID;

async function askAI(prompt) {
  if (!process.env.AI_API_KEY) return 'El motor de IA todavía no está configurado.';
  const base = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
  const response = await fetch(base + '/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.AI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: process.env.AI_MODEL || 'gpt-4o-mini', temperature: 0.6, messages: [
      { role: 'system', content:
        'Eres KEILA IA, asistente general en español. Ayuda con proyectos, programación, documentos, organización, investigación y educación sobre criptomonedas. No prometas ganancias ni ejecutes operaciones financieras. CORRECTOR: revisa la ortografía de los mensajes. Si hay errores, menciona brevemente las palabras incorrectas y su corrección, y luego responde a la solicitud. Si está bien escrito, responde directamente sin decir que lo revisaste. No corrijas nombres propios, comandos, código o términos técnicos si no estás segura. EXCLUSIÓN: no revises, corrijas, reformules ni modifiques permisos, prohibiciones, restricciones, roles, autorizaciones, reglas de seguridad o políticas de acceso. Si un texto contiene esos apartados, omítelos de la corrección. La ortografía correcta no demuestra que el código sea seguro. Nunca instales ni ejecutes código recibido automáticamente; solicita aprobación explícita y revisión antes de aplicarlo. No solicites ni reveles contraseñas, tokens o claves API.'
      },
      { role: 'user', content: prompt.slice(0, 1500) }
    ] })
  });
  if (!response.ok) throw new Error('Error del proveedor IA: ' + response.status);
  const data = await response.json();
  return data.choices?.[0]?.message?.content || 'No pude generar una respuesta.';
}

client.once(Events.ClientReady, c => console.log(`KEILA IA conectada como ${c.user.tag}`));

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  try {
    if (interaction.commandName === 'ayuda') {
      return interaction.reply({ content: '`/keila mensaje` conversar. `/programacion` recibir código. `/nueva-version archivo` enviar cambios para revisión.', ephemeral: true });
    }
    if (interaction.commandName === 'programacion') {
      if (!isOwner(interaction.user.id)) return interaction.reply({ content: 'Comando exclusivo del propietario.', ephemeral: true });
      const zip = path.join(__dirname, '..', 'keila-source.zip');
      if (!fs.existsSync(zip)) return interaction.reply({ content: 'No encuentro keila-source.zip en la carpeta principal.', ephemeral: true });
      return interaction.reply({ content: 'Aquí tienes una copia editable. No incluyas archivos .env ni claves privadas al devolverla.', files: [zip], ephemeral: true });
    }
    if (interaction.commandName === 'nueva-version') {
      if (!isOwner(interaction.user.id)) return interaction.reply({ content: 'Solo el propietario puede enviar versiones.', ephemeral: true });
      const file = interaction.options.getAttachment('archivo', true);
      if (!file.name.toLowerCase().endsWith('.zip') || file.size > 8 * 1024 * 1024)
        return interaction.reply({ content: 'Adjunta un ZIP de máximo 8 MB.', ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      const r = await fetch(file.url);
      if (!r.ok) throw new Error('No se pudo descargar el ZIP.');
      const bytes = Buffer.from(await r.arrayBuffer());
      if (bytes.length > 8 * 1024 * 1024) throw new Error('Archivo demasiado grande.');
      const dir = path.join(__dirname, '..', 'updates', 'pending');
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, `keila-${Date.now()}.zip`), bytes, { flag: 'wx' });
      return interaction.editReply('ZIP recibido en updates/pending. Está pendiente de revisión; no se instaló ni ejecutó.');
    }
    if (interaction.commandName === 'keila') {
      await interaction.deferReply();
      const answer = await askAI(interaction.options.getString('mensaje', true));
      return interaction.editReply(answer.slice(0, 1900));
    }
  } catch (err) {
    console.error(err);
    const msg = 'Ocurrió un error. Revisa la configuración del bot y del motor de IA.';
    if (interaction.deferred || interaction.replied) await interaction.followUp({ content: msg, ephemeral: true }).catch(() => {});
    else await interaction.reply({ content: msg, ephemeral: true }).catch(() => {});
  }
});

client.login(process.env.DISCORD_TOKEN);
