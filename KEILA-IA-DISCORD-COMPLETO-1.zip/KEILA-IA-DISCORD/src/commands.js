const { SlashCommandBuilder } = require('discord.js');
module.exports.commands = [
  new SlashCommandBuilder().setName('keila').setDescription('Habla con KEILA IA')
    .addStringOption(o => o.setName('mensaje').setDescription('Tu mensaje').setRequired(true).setMaxLength(1500)),
  new SlashCommandBuilder().setName('programacion').setDescription('Recibe una copia editable del código (solo propietario)'),
  new SlashCommandBuilder().setName('nueva-version').setDescription('Envía un ZIP editado para revisión (solo propietario)')
    .addAttachmentOption(o => o.setName('archivo').setDescription('ZIP actualizado').setRequired(true)),
  new SlashCommandBuilder().setName('ayuda').setDescription('Muestra los comandos')
].map(c => c.toJSON());
