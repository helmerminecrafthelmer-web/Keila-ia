require('dotenv').config();
const { REST, Routes } = require('discord.js');
const { commands } = require('./commands');
(async () => {
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
  await rest.put(Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, process.env.DISCORD_GUILD_ID), { body: commands });
  console.log('Comandos de KEILA registrados.');
})().catch(e => { console.error(e); process.exit(1); });
